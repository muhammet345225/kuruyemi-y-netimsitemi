-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2025 at 03:22 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kuruyemisphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adm_id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `code` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adm_id`, `username`, `password`, `email`, `code`, `date`) VALUES
(1, 'admin', '0192023a7bbd73250516f069df18b500', 'admin@kuruyemis.com', '', '2025-05-07 13:21:52');

-- --------------------------------------------------------

--
-- Table structure for table `dishes`
--

CREATE TABLE `dishes` (
  `d_id` int(222) NOT NULL,
  `rs_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `slogan` varchar(222) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `img` varchar(222) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER DATABASE kuruyemisphp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE users_orders CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE users_orders MODIFY title VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE users_orders MODIFY slogan VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

INSERT INTO `dishes` (`d_id`, `rs_id`, `title`, `slogan`, `price`, `img`) VALUES
(1, 1, 'Premium Badem', 'E vitamini ve antioksidanlar açısından zengin, doğal Kaliforniya bademi', '12.00', '62908867a48e4.jpg'),
(2, 1, 'Organik Ceviz', 'Omega-3 yağ asitleriyle dolu taze organik cevizler', '15.00', '629089fee52b9.jpg'),
(3, 1, 'Türk Kayısıları', 'Malatya’dan gelen doğal tatlı ve yumuşak kuru kayısılar', '8.00', '62908bdf2f581.jpg'),
(4, 1, 'Antep Fıstığı', 'Hafif tuzlanmış premium İran Antep fıstığı', '18.00', '62908d393465b.jpg'),
(5, 1, 'Kaju Fıstığı', 'Vietnam’dan gelen kremamsı ve lezzetli çiğ kaju', '14.00', '606d7491a9d13.jpg'),
(6, 1, 'Kuru İncir', 'Lif ve mineraller bakımından zengin Ege incirleri', '10.00', '606d74c416da5.jpg'),
(7, 1, 'Fındık', 'Atıştırmalık için mükemmel kalitede Türk fındığı', '11.00', '606d74f6ecbbb.jpg'),
(8, 1, 'Güneşte Kurutulmuş Üzüm', 'Çekirdeksiz koyu renkli üzümler, doğal yollarla kurutulmuş', '7.00', '606d752a209c3.jpg'),
(9, 1, 'Brezilya Cevizi', 'Selenyum açısından zengin, bağışıklık desteği için ideal', '16.00', '606d7575798fb.jpg'),
(10, 1, 'Pekan Cevizi', 'Tereyağlı ve tatlı, tatlılar için mükemmel', '20.00', '606d75a7e21ec.jpg'),
(11, 1, 'Makademya Fındığı', 'Kremamsı ve zengin aromalı, kuruyemişlerin kralı', '25.00', '606d75ce105d0.jpg'),
(12, 1, 'Kuru Turna Yemişi', 'Ekşi-tatlı aromalı, salatalar ve fırın ürünleri için ideal', '9.00', '606d7600dc54c.jpg'),
(13, 1, 'Çam Fıstığı', 'Nazik aromasıyla pesto ve salatalar için ideal', '22.00', '606d765f69a19.jpg'),
(14, 1, 'Kuru Mango', 'Tatlı ve sakız gibi, ilave şeker içermez', '8.00', '606d768a1b2a1.jpg'),
(15, 1, 'Kuru Muz Cipsi', 'Gevrek ve doğal olarak tatlı', '6.00', '606d76ad0c0cb.jpg'),
(16, 1, 'Karışık Kuruyemiş', 'Badem, kaju, ceviz ve fındıktan oluşan premium karışım', '15.00', '606d76eedbb99.jpg');
-- --------------------------------------------------------

--
-- Table structure for table `remark`
--

CREATE TABLE `remark` (
  `id` int(11) NOT NULL,
  `frm_id` int(11) NOT NULL,
  `status` varchar(255) NOT NULL,
  `remark` mediumtext NOT NULL,
  `remarkDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
ALTER DATABASE kuruyemisphp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE res_category CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE res_category MODIFY status VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;--
--

INSERT INTO `remark` (`id`, `frm_id`, `status`, `remark`, `remarkDate`) VALUES
(1, 2, 'işlemde', 'yok', '2025-05-01 05:17:49'),
(2, 3, 'işlemde', 'yok', '2025-05-07 11:01:30'),
(3, 2, 'kapatıldı', 'siparişiniz için teşekkür ederiz!', '2025-05-07 11:11:41'),
(4, 3, 'kapatıldı', 'yok', '2025-05-07 11:42:35'),
(5, 4, 'işlemde', 'yok', '2025-05-07 11:42:55'),
(6, 1, 'reddedildi', 'yok', '2025-05-07 11:43:26'),
(7, 7, 'işlemde', 'yok', '2025-05-07 13:03:24'),
(8, 8, 'işlemde', 'yok', '2025-05-07 13:03:38'),
(9, 9, 'reddedildi', 'teşekkürler', '2025-05-07 13:03:53'),
(10, 7, 'kapatıldı', 'bizden sipariş verdiğiniz için teşekkür ederiz', '2025-05-07 13:04:33'),
(11, 8, 'kapatıldı', 'teşekkürler', '2025-05-07 13:05:24'),
(12, 5, 'kapatıldı', 'yok', '2025-05-07 13:18:03');
-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `rs_id` int(222) NOT NULL,
  `c_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `url` varchar(222) NOT NULL,
  `o_hr` varchar(222) NOT NULL,
  `c_hr` varchar(222) NOT NULL,
  `o_days` varchar(222) NOT NULL,
  `address` text NOT NULL,
  `image` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
ALTER DATABASE kuruyemisphp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE res_category CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE res_category MODIFY title VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;--
--

INSERT INTO `restaurant` (`rs_id`, `c_id`, `title`, `email`, `phone`, `url`, `o_hr`, `c_hr`, `o_days`, `address`, `image`, `date`) VALUES
(1, 1, 'Premium Kuru Yemiş', 'info@premiumkuruyemis.com', '5551234567', 'www.premiumkuruyemis.com', '8am', '8pm', 'mon-sat', '123 Main Street, Istanbul', '6290877b473ce.jpg', '2025-05-07 08:10:35');

-- --------------------------------------------------------

--
-- Table structure for table `res_category`
--

CREATE TABLE `res_category` (
  `c_id` int(222) NOT NULL,
  `c_name` varchar(222) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
ALTER DATABASE kuruyemisphp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE res_category CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE res_category MODIFY c_name VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;--

INSERT INTO `res_category` (`c_id`, `c_name`, `date`) VALUES
(1, 'Kuru Meyveler ve Kuruyemişler', '2025-05-07 08:07:35');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(222) NOT NULL,
  `username` varchar(222) NOT NULL,
  `f_name` varchar(222) NOT NULL,
  `l_name` varchar(222) NOT NULL,
  `email` varchar(222) NOT NULL,
  `phone` varchar(222) NOT NULL,
  `password` varchar(222) NOT NULL,
  `address` text NOT NULL,
  `status` int(222) NOT NULL DEFAULT '1',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER DATABASE kuruyemisphp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE users CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

INSERT INTO `users` (`u_id`, `username`, `f_name`, `l_name`, `email`, `phone`, `password`, `address`, `status`, `date`) VALUES
(1, 'ahmet', 'Ahmet', 'Yılmaz', 'ahmet@mail.com', '5551112233', 'a32de55ffd7a9c4101a0c5c8788b38ed', '45 Bahçe Street, Istanbul', 1, '2025-05-07 08:40:36'),
(2, 'mehmet', 'Mehmet', 'Kaya', 'mehmet@mail.com', '5552223344', 'bc28715006af20d0e961afd053a984d9', '78 Ordu Avenue, Ankara', 1, '2025-05-07 08:41:07'),
(3, 'ayse', 'Ayşe', 'Demir', 'ayse@mail.com', '5553334455', '58b2318af54435138065ee13dd8bea16', '23 Gül Street, Izmir', 1, '2025-05-07 08:41:37'),
(4, 'fatma', 'Fatma', 'Şahin', 'fatma@mail.com', '5554445566', '5f4dcc3b5aa765d61d8327deb882cf99', '89 Deniz Road, Bursa', 1, '2025-05-01 05:14:42'),
(5, 'mustafa', 'Mustafa', 'Arslan', 'mustafa@mail.com', '5555556677', '5f4dcc3b5aa765d61d8327deb882cf99', '12 Tepe Street, Antalya', 1, '2025-05-07 10:53:51'),
(6, 'zeynep', 'Zeynep', 'Koç', 'zeynep@mail.com', '5556667788', '5f4dcd3b5aa765d61d8327deb882cf99', '34 Çınar Avenue, Adana', 1, '2025-05-07 12:57:00');

-- --------------------------------------------------------

--
-- Table structure for table `users_orders`
--

CREATE TABLE `users_orders` (
  `o_id` int(222) NOT NULL,
  `u_id` int(222) NOT NULL,
  `title` varchar(222) NOT NULL,
  `quantity` int(222) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` varchar(222) DEFAULT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER DATABASE kuruyemisphp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE users_orders CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE users_orders MODIFY title VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

INSERT INTO `users_orders` (`o_id`, `u_id`, `title`, `quantity`, `price`, `status`, `date`) VALUES
(1, 4, 'Organik Ceviz', 2, '15.00', 'reddedildi', '2025-05-07 11:43:26'),
(2, 4, 'Türk Kayısısı', 1, '8.00', 'kapatıldı', '2025-05-07 11:11:41'),
(3, 5, 'Premium Badem', 1, '12.00', 'kapatıldı', '2025-05-07 11:42:35'),
(4, 5, 'Kuru İncir', 1, '10.00', 'işlemde', '2025-05-07 11:42:55'),
(5, 5, 'Karışık Kuruyemiş', 1, '15.00', 'kapatıldı', '2025-05-07 13:18:03'),
(6, 5, 'Fındık', 1, '11.00', NULL, '2025-05-07 11:40:51'),
(7, 6, 'Antep Fıstığı', 1, '18.00', 'kapatıldı', '2025-05-07 13:04:33'),
(8, 6, 'Makademya Fındığı', 1, '25.00', 'kapatıldı', '2025-05-07 13:05:24'),
(9, 6, 'Kuru Mango', 1, '8.00', 'reddedildi', '2025-05-07 13:03:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adm_id`);

--
-- Indexes for table `dishes`
--
ALTER TABLE `dishes`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `remark`
--
ALTER TABLE `remark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`rs_id`);

--
-- Indexes for table `res_category`
--
ALTER TABLE `res_category`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- Indexes for table `users_orders`
--
ALTER TABLE `users_orders`
  ADD PRIMARY KEY (`o_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adm_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `dishes`
--
ALTER TABLE `dishes`
  MODIFY `d_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `remark`
--
ALTER TABLE `remark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `rs_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `res_category`
--
ALTER TABLE `res_category`
  MODIFY `c_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `users_orders`
--
ALTER TABLE `users_orders`
  MODIFY `o_id` int(222) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;