<!DOCTYPE html>
<html lang="tr">
<?php
session_start(); 
error_reporting(0); 
include("connection/connect.php"); 
if(isset($_POST['submit'] )) 
{
     if(empty($_POST['firstname']) || 
   	    empty($_POST['lastname'])|| 
		empty($_POST['email']) ||  
		empty($_POST['phone'])||
		empty($_POST['password'])||
		empty($_POST['cpassword']) ||
		empty($_POST['cpassword']))
		{
			$message = "Tüm alanlar doldurulmalıdır!";
		}
	else
	{
	
	$check_username= mysqli_query($db, "SELECT username FROM users where username = '".$_POST['username']."' ");
	$check_email = mysqli_query($db, "SELECT email FROM users where email = '".$_POST['email']."' ");
		

	
	if($_POST['password'] != $_POST['cpassword']){  
       	
          echo "<script>alert('Şifreler uyuşmuyor');</script>"; 
    }
	elseif(strlen($_POST['password']) < 6)  
	{
      echo "<script>alert('Şifre en az 6 karakter olmalıdır');</script>"; 
	}
	elseif(strlen($_POST['phone']) < 10)  
	{
      echo "<script>alert('Geçersiz telefon numarası!');</script>"; 
	}

    elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) 
    {
          echo "<script>alert('Geçersiz email adresi! Lütfen geçerli bir email adresi girin');</script>"; 
    }
	elseif(mysqli_num_rows($check_username) > 0) 
     {
       echo "<script>alert('Bu kullanıcı adı zaten kullanılıyor!');</script>"; 
     }
	elseif(mysqli_num_rows($check_email) > 0) 
     {
       echo "<script>alert('Bu email adresi zaten kullanılıyor!');</script>"; 
     }
	else{
       
	 
	$mql = "INSERT INTO users(username,f_name,l_name,email,phone,password,address) VALUES('".$_POST['username']."','".$_POST['firstname']."','".$_POST['lastname']."','".$_POST['email']."','".$_POST['phone']."','".md5($_POST['password'])."','".$_POST['address']."')";
	mysqli_query($db, $mql);
	
		 header("refresh:0.1;url=login.php");
    }
	}

}
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="#">
    <title>Kayıt Ol</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
<div style=" background-image: url('images/img/pimg.jpg');">
    <header id="header" class="header-scroll top-header headrom">
        <nav class="navbar navbar-dark">
            <div class="container">
                <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                <a class="navbar-brand d-flex align-items-center" href="index.php" style="gap: 10px;">
                    <img src="images/icn.png" alt="Logo" style="height: 40px; width: auto;" class="img-rounded">
                    <span style="font-weight: bold; font-size: 20px; color: #fff;">kuru yemiş</span>
                </a>
                <div class="collapse navbar-toggleable-md float-lg-right" id="mainNavbarCollapse">
                    <ul class="nav navbar-nav">
                        <li class="nav-item"><a class="nav-link active" href="index.php">Ana Sayfa <span class="sr-only">(current)</span></a></li>
                        <li class="nav-item"><a class="nav-link active" href="restaurants.php">Mağazalar <span class="sr-only"></span></a></li>
                        
                        <?php
                        if(empty($_SESSION["user_id"])) {
                            echo '<li class="nav-item"><a href="login.php" class="nav-link active">Giriş Yap</a></li>
                                  <li class="nav-item"><a href="registration.php" class="nav-link active">Kayıt Ol</a></li>';
                        } else {
                            echo '<li class="nav-item"><a href="your_orders.php" class="nav-link active">Siparişlerim</a></li>
                                  <li class="nav-item"><a href="logout.php" class="nav-link active">Çıkış Yap</a></li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="page-wrapper">
        <section class="contact-page inner-page">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="widget">
                            <div class="widget-body">
                                <form action="" method="post">
                                    <div class="row">
                                        <div class="form-group col-sm-12">
                                            <label for="exampleInputEmail1">Kullanıcı Adı</label>
                                            <input class="form-control" type="text" name="username" id="example-text-input" required> 
                                        </div>
                                        <div class="form-group col-sm-6">
                                            <label for="exampleInputEmail1">Ad</label>
                                            <input class="form-control" type="text" name="firstname" id="example-text-input" required> 
                                        </div>
                                        <div class="form-group col-sm-6">
                                            <label for="exampleInputEmail1">Soyad</label>
                                            <input class="form-control" type="text" name="lastname" id="example-text-input-2" required> 
                                        </div>
                                        <div class="form-group col-sm-6">
                                            <label for="exampleInputEmail1">Email Adresi</label>
                                            <input type="text" class="form-control" name="email" id="exampleInputEmail1" aria-describedby="emailHelp" required> 
                                        </div>
                                        <div class="form-group col-sm-6">
                                            <label for="exampleInputEmail1">Telefon Numarası</label>
                                            <input class="form-control" type="text" name="phone" id="example-tel-input-3" required> 
                                        </div>
                                        <div class="form-group col-sm-6">
                                            <label for="exampleInputPassword1">Şifre</label>
                                            <input type="password" class="form-control" name="password" id="exampleInputPassword1" required> 
                                        </div>
                                        <div class="form-group col-sm-6">
                                            <label for="exampleInputPassword1">Şifreyi Onayla</label>
                                            <input type="password" class="form-control" name="cpassword" id="exampleInputPassword2" required> 
                                        </div>
                                        <div class="form-group col-sm-12">
                                            <label for="exampleTextarea">Teslimat Adresi</label>
                                            <textarea class="form-control" id="exampleTextarea" name="address" rows="3" required></textarea>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <p><input type="submit" value="Kayıt Ol" name="submit" class="btn theme-btn"></p>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <footer class="footer">
            <div class="container">
                <div class="row bottom-footer">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 col-sm-3 payment-options color-gray">
                                <h5>Ödeme Seçenekleri</h5>
                                <ul>
                                    <li><a href="#"><img src="images/paypal.png" alt="Paypal"></a></li>
                                    <li><a href="#"><img src="images/mastercard.png" alt="Mastercard"></a></li>
                                    <li><a href="#"><img src="images/maestro.png" alt="Maestro"></a></li>
                                    <li><a href="#"><img src="images/stripe.png" alt="Stripe"></a></li>
                                    <li><a href="#"><img src="images/bitcoin.png" alt="Bitcoin"></a></li>
                                </ul>
                            </div>
                            <div class="col-xs-12 col-sm-4 address color-gray">
                                <h5>Adres</h5>
                                <p>HATAY, TÜRKYE</p>
                                <h5>Telefon: +90 505 048 35 88</h5>
                            </div>
                            <div class="col-xs-12 col-sm-5 additional-info color-gray">
                                <h5>Ek Bilgiler</h5>
                                <p>Binlerce kuru yemiş mağazasıyla işbirliği yaparak sizlere en kaliteli ürünleri sunuyoruz.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/tether.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/animsition.min.js"></script>
<script src="js/bootstrap-slider.min.js"></script>
<script src="js/jquery.isotope.min.js"></script>
<script src="js/headroom.js"></script>
<script src="js/foodpicky.min.js"></script>
</body>
</html>